import os

def replace_file_substring(directory, new_content, old_content):
    """
    Searches a directory recursively for files ending in '.def' or '.inc'.
    If 'old_content' is found as a substring within the file, it is 
    replaced with 'new_content'.
    """
    
    # 1. Check if the directory exists
    if not os.path.isdir(directory):
        print(f"Error: Directory not found: {directory}")
        return

    # Counter for replaced files
    replaced_count = 0
    
    # 2. Walk through the directory and its subdirectories
    for root, dirs, files in os.walk(directory):
        for file in files:
            # 3. Filter files by extension
            if file.endswith('.def') or file.endswith('.inc'):
                file_path = os.path.join(root, file)
                
                try:
                    # 4. Read the current content of the file
                    with open(file_path, 'r', encoding='utf-8') as f:
                        current_content = f.read()
                        
                    # 5. Check if the old content exists as a substring
                    if old_content in current_content:
                        # 6. Perform the replacement in memory
                        new_file_content = current_content.replace(old_content, new_content)
                        
                        # 7. Write the modified content back to the file
                        # Using 'w' for write mode (will overwrite)
                        with open(file_path, 'w', encoding='utf-8') as f:
                            f.write(new_file_content)
                        
                        print(f"✅ Replaced substring in file: {file_path}")
                        replaced_count += 1
                    else:
                        print(f"⏭️ Skipping file: {file_path} - Substring not found.")

                except IOError as e:
                    # Handle cases where the file can't be opened or read/written
                    print(f"❌ Error processing file {file_path}: {e}")
                    
    print(f"\n--- Summary ---")
    print(f"Finished processing directory: {directory}")
    print(f"Total files where content was modified: {replaced_count}")

# --- Original Variables ---
directory_path = './-vehicle/'

# IMPORTANT NOTE: The string matching is exact. You might need to adjust 
# the indentation of these blocks in the variables below to ensure a match 
# with the indentation used in your actual files. I've standardized the 
# formatting for demonstration.
old_content = """{armor
		(include "/set/mod_config/superhealthbar.inc")
	}"""

new_content = """{extender "auto_restore_fuel_point"
		{radius 32}
		{type "static"}
	}

	{extender "auto_restore_warehouse"
		{radius 32}
		{type "static"}
	}

	{extender "inventory"
		{box
			{size 12 16}
		}
	}"""

# --- Execution ---
replace_file_substring(directory_path, new_content, old_content)
