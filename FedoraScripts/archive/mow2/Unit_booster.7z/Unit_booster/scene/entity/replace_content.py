import os

def replace_file_content(directory, new_content, old_content):
    """
    Searches a directory recursively for files ending in '.def' or '.inc'.
    If a file's content exactly matches 'old_content', it is replaced 
    with 'new_content'.
    """
    
    # 1. Check if the directory exists
    if not os.path.isdir(directory):
        print(f"Error: Directory not found: {directory}")
        return

    # Counter for replaced files
    replaced_count = 0
    
    # 2. Walk through the directory and its subdirectories
    for root, dirs, files in os.walk(directory):
        for file in files:
            # 3. Filter files by extension
            if file.endswith('.def') or file.endswith('.inc'):
                file_path = os.path.join(root, file)
                
                try:
                    # 4. Read the current content of the file
                    # Using 'r' for read mode
                    with open(file_path, 'r', encoding='utf-8') as f:
                        current_content = f.read()
                        
                    # 5. Check if the current content matches the target content
                    if current_content == old_content:
                        # 6. Content matches, now write the new content
                        # Using 'w' for write mode (will overwrite)
                        with open(file_path, 'w', encoding='utf-8') as f:
                            f.write(new_content)
                        
                        print(f"✅ Replaced content in file: {file_path}")
                        replaced_count += 1
                    else:
                        print(f"⏭️ Skipping file: {file_path} - Content does not match 'old_content'.")

                except IOError as e:
                    # Handle cases where the file can't be opened or read/written
                    print(f"❌ Error processing file {file_path}: {e}")
                    
    print(f"\n--- Summary ---")
    print(f"Finished processing directory: {directory}")
    print(f"Total files replaced: {replaced_count}")

# --- Original Variables ---
directory_path = './-vehicle/'

old_content = """{game_entity
    {armor
        (include "/set/mod_config/superhealthbar.inc")
    }
}
"""

new_content = """{game_entity
	{extender "auto_restore_fuel_point"
		{radius 32}
		{type "static"}
	}

	{extender "auto_restore_warehouse"
		{radius 32}
		{type "static"}
	}

	{extender "inventory"
		{box
			{size 12 16}
		}
	}
}
"""
# --- Execution ---
replace_file_content(directory_path, new_content, old_content)
